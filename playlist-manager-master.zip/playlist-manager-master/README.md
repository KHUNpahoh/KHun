# Playlist Manager for Spotify

Check it out at http://playlist-manager.com/ (Currently only for Chrome Browser)

Playlist Manager merges the songs of selected playlists into one view, allowing users to easily add and remove songs from several playlists.

It counts with the ability to sort songs by different parameters, most noticeably by date added to a specific playlist, or among all playlists. This helps users to keep updated with the songs of many different playlists he follows, and easily add them to his own playlists.

Users can also quickly play a preview of any song, as well as play the full song inside Spotify with the Spotify Play Button.

Tips, suggestions and contributions are welcome!

Using Angular1, planning to redo it with Angular2.
